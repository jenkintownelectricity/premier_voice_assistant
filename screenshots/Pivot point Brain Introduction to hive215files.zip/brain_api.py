"""
Fast Brain API - The Plugin Interface

This module wraps your BitNet LPU and exposes it as an HTTP/WebSocket API
that any voice platform can connect to.

Deploy with:
    modal deploy brain_api.py

Your API will be available at:
    https://<your-username>--fast-brain-api-fastapi-app.modal.run

Usage from any platform:
    POST /api/v1/think     - Get AI response
    WS   /api/v1/stream    - Real-time token streaming
    POST /api/v1/turn      - Turn-taking analysis
    GET  /api/v1/skills    - List available skill adapters
    POST /api/v1/feedback  - Log corrections for learning
    GET  /api/v1/health    - Health check
"""

import modal
import os
import time
import json
import asyncio
from typing import Optional, List, Dict, Any
from datetime import datetime
from pathlib import Path
from enum import Enum

# =============================================================================
# MODAL APP SETUP
# =============================================================================

app = modal.App("fast-brain-api")

# Image with all dependencies
brain_image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "fastapi",
        "pydantic",
        "websockets",
        "httpx",
    )
)

# Volume for feedback logs (persistent)
feedback_volume = modal.Volume.from_name("brain-feedback", create_if_missing=True)

# Reference to the LPU (deployed separately via modal_lpu.py)
# This allows hot-swapping the LPU without redeploying the API
LPU_APP_NAME = "bitnet-lpu-v1"
LPU_CLASS_NAME = "VirtualLPU"


# =============================================================================
# PYDANTIC MODELS
# =============================================================================

from pydantic import BaseModel, Field


class ThinkRequest(BaseModel):
    """Request to get an AI response."""
    user_input: str = Field(..., description="The user's message")
    skill: str = Field(default="default", description="Skill adapter to use (e.g., 'plumber')")
    conversation_id: Optional[str] = Field(default=None, description="ID to track conversation")
    context: Optional[Dict[str, Any]] = Field(default=None, description="Additional context")
    max_tokens: int = Field(default=256, description="Maximum tokens to generate")
    
    
class ThinkResponse(BaseModel):
    """Response from the AI."""
    response: str = Field(..., description="The AI's response text")
    confidence: float = Field(..., description="Confidence score 0-1")
    tokens_used: int = Field(..., description="Number of tokens in response")
    latency_ms: float = Field(..., description="Processing time in milliseconds")
    skill_used: str = Field(..., description="Which skill adapter was used")


class TurnRequest(BaseModel):
    """Request for turn-taking analysis."""
    transcript: str = Field(..., description="Current transcript of user speech")
    silence_ms: float = Field(..., description="Milliseconds of silence detected")
    is_agent_speaking: bool = Field(default=False, description="Is the agent currently speaking")
    energy_level: Optional[float] = Field(default=None, description="Audio energy level 0-1")


class TurnAction(str, Enum):
    WAIT = "WAIT"               # Keep listening, user may continue
    RESPOND = "RESPOND"         # User is done, generate response
    BACKCHANNEL = "BACKCHANNEL" # Say "uh-huh" or similar
    INTERRUPT = "INTERRUPT"     # User interrupted agent


class TurnResponse(BaseModel):
    """Response from turn analysis."""
    action: TurnAction = Field(..., description="Recommended action")
    confidence: float = Field(..., description="Confidence in this action")
    reason: str = Field(..., description="Explanation of the decision")


class FeedbackRequest(BaseModel):
    """Feedback for continuous learning."""
    conversation_id: str = Field(..., description="Conversation this feedback is for")
    user_input: str = Field(..., description="What the user said")
    agent_response: str = Field(..., description="What the agent responded")
    rating: int = Field(..., ge=1, le=5, description="Rating 1-5")
    correction: Optional[str] = Field(default=None, description="Better response if rating low")
    skill: Optional[str] = Field(default=None, description="Skill that was used")


class SkillInfo(BaseModel):
    """Information about a skill adapter."""
    id: str
    name: str
    description: Optional[str] = None
    version: str = "1.0"
    last_trained: Optional[str] = None


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    lpu_connected: bool
    skills_available: int
    uptime_seconds: float
    version: str = "1.0.0"


# =============================================================================
# TURN-TAKING LOGIC (Simplified from turn_taking.py)
# =============================================================================

class SimpleTurnDetector:
    """
    Simplified turn-taking detection.
    For full implementation, import from turn_taking.py
    """
    
    # Patterns suggesting user is DONE
    END_PATTERNS = [
        "?",           # Questions
        ".",           # Statements
        "!",           # Exclamations
        "thanks",
        "thank you",
        "that's all",
        "that's it",
        "okay bye",
        "goodbye",
    ]
    
    # Patterns suggesting user will CONTINUE
    CONTINUE_PATTERNS = [
        " and ",
        " but ",
        " so ",
        " because ",
        "...",
        ", um",
        ", uh",
        " like ",
    ]
    
    # Backchannel phrases (don't count as real turns)
    BACKCHANNELS = [
        "uh-huh",
        "mm-hmm", 
        "yeah",
        "okay",
        "right",
        "got it",
        "i see",
    ]
    
    def analyze(
        self, 
        transcript: str, 
        silence_ms: float, 
        is_agent_speaking: bool
    ) -> TurnResponse:
        """Analyze if user is done speaking."""
        
        text = transcript.lower().strip()
        
        # If agent is speaking and user talks, it's an interrupt
        if is_agent_speaking and len(text) > 10:
            return TurnResponse(
                action=TurnAction.INTERRUPT,
                confidence=0.9,
                reason="User spoke while agent was talking"
            )
        
        # Check for backchannels
        for bc in self.BACKCHANNELS:
            if text == bc or text.endswith(bc):
                return TurnResponse(
                    action=TurnAction.BACKCHANNEL,
                    confidence=0.8,
                    reason=f"Detected backchannel: {bc}"
                )
        
        # Long silence = user done
        if silence_ms > 1500:
            return TurnResponse(
                action=TurnAction.RESPOND,
                confidence=0.95,
                reason=f"Long silence ({silence_ms}ms)"
            )
        
        # Check continue patterns
        for pattern in self.CONTINUE_PATTERNS:
            if pattern in text[-20:]:  # Check end of transcript
                return TurnResponse(
                    action=TurnAction.WAIT,
                    confidence=0.7,
                    reason=f"Continue pattern detected: '{pattern}'"
                )
        
        # Check end patterns with sufficient silence
        if silence_ms > 500:
            for pattern in self.END_PATTERNS:
                if text.endswith(pattern) or pattern in text[-10:]:
                    return TurnResponse(
                        action=TurnAction.RESPOND,
                        confidence=0.85,
                        reason=f"End pattern '{pattern}' + {silence_ms}ms silence"
                    )
        
        # Default: keep waiting
        return TurnResponse(
            action=TurnAction.WAIT,
            confidence=0.6,
            reason="No clear turn boundary detected"
        )


# =============================================================================
# FASTAPI APPLICATION
# =============================================================================

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware

# Track startup time
START_TIME = time.time()

# Create FastAPI app
web_app = FastAPI(
    title="Fast Brain API",
    description="Brain-as-a-Service for voice AI platforms",
    version="1.0.0",
)

# CORS for browser access
web_app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Turn detector instance
turn_detector = SimpleTurnDetector()


def get_lpu():
    """Get reference to the LPU class."""
    try:
        return modal.Cls.lookup(LPU_APP_NAME, LPU_CLASS_NAME)
    except Exception as e:
        print(f"Warning: Could not connect to LPU: {e}")
        return None


# =============================================================================
# API ENDPOINTS
# =============================================================================

@web_app.get("/api/v1/health", response_model=HealthResponse)
async def health_check():
    """Check API health and LPU connectivity."""
    lpu = get_lpu()
    lpu_connected = lpu is not None
    
    skills_count = 0
    if lpu_connected:
        try:
            skills = lpu().list_skills.remote()
            skills_count = len(skills) if skills else 0
        except:
            lpu_connected = False
    
    return HealthResponse(
        status="healthy" if lpu_connected else "degraded",
        lpu_connected=lpu_connected,
        skills_available=skills_count,
        uptime_seconds=time.time() - START_TIME,
    )


@web_app.post("/api/v1/think", response_model=ThinkResponse)
async def think(request: ThinkRequest):
    """
    Core inference endpoint.
    Send user text, get AI response.
    """
    start = time.time()
    
    lpu = get_lpu()
    if lpu is None:
        raise HTTPException(status_code=503, detail="LPU not available")
    
    # Build prompt
    prompt = f"User: {request.user_input}\nAssistant:"
    
    # Determine skill adapter
    skill_adapter = None
    if request.skill and request.skill != "default":
        skill_adapter = f"{request.skill}.lora"
    
    # Call LPU
    try:
        response_text = ""
        for chunk in lpu().chat.remote_gen(
            prompt,
            skill_adapter=skill_adapter,
            max_tokens=request.max_tokens
        ):
            response_text += chunk
        
        # Clean up response
        response_text = response_text.strip()
        if response_text.startswith("Assistant:"):
            response_text = response_text[10:].strip()
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"LPU error: {str(e)}")
    
    latency = (time.time() - start) * 1000
    
    return ThinkResponse(
        response=response_text,
        confidence=0.9,  # TODO: Calculate from LPU
        tokens_used=len(response_text.split()),
        latency_ms=latency,
        skill_used=request.skill or "default"
    )


@web_app.post("/api/v1/turn", response_model=TurnResponse)
async def analyze_turn(request: TurnRequest):
    """
    Turn-taking analysis.
    Determines if the user is done speaking.
    """
    return turn_detector.analyze(
        transcript=request.transcript,
        silence_ms=request.silence_ms,
        is_agent_speaking=request.is_agent_speaking
    )


@web_app.get("/api/v1/skills")
async def list_skills() -> Dict[str, List[SkillInfo]]:
    """List all available skill adapters."""
    lpu = get_lpu()
    
    if lpu is None:
        return {"skills": []}
    
    try:
        skill_files = lpu().list_skills.remote()
        skills = []
        
        for skill_file in (skill_files or []):
            # Parse skill name from filename
            name = skill_file.replace(".lora", "").replace("_", " ").title()
            skills.append(SkillInfo(
                id=skill_file.replace(".lora", ""),
                name=name,
                description=f"Expert skill for {name}",
            ))
        
        return {"skills": skills}
        
    except Exception as e:
        print(f"Error listing skills: {e}")
        return {"skills": []}


@web_app.post("/api/v1/feedback")
async def log_feedback(request: FeedbackRequest):
    """
    Log feedback for continuous learning.
    Stored for later DPO training.
    """
    feedback_entry = {
        "timestamp": datetime.now().isoformat(),
        "conversation_id": request.conversation_id,
        "user_input": request.user_input,
        "agent_response": request.agent_response,
        "rating": request.rating,
        "correction": request.correction,
        "skill": request.skill,
    }
    
    # Write to feedback volume
    feedback_path = Path("/feedback/feedback.jsonl")
    
    try:
        with open(feedback_path, "a") as f:
            f.write(json.dumps(feedback_entry) + "\n")
    except Exception as e:
        print(f"Warning: Could not write feedback: {e}")
    
    # If there's a correction, also log as DPO pair
    if request.correction and request.rating <= 2:
        dpo_entry = {
            "timestamp": datetime.now().isoformat(),
            "prompt": request.user_input,
            "chosen": request.correction,
            "rejected": request.agent_response,
            "skill": request.skill,
        }
        
        try:
            dpo_path = Path("/feedback/dpo_pairs.jsonl")
            with open(dpo_path, "a") as f:
                f.write(json.dumps(dpo_entry) + "\n")
        except Exception as e:
            print(f"Warning: Could not write DPO pair: {e}")
    
    return {"status": "logged", "conversation_id": request.conversation_id}


@web_app.websocket("/api/v1/stream")
async def stream_response(websocket: WebSocket):
    """
    WebSocket for real-time token streaming.
    Lowest latency option for voice platforms.
    
    Protocol:
        Send: {"type": "think", "text": "user message", "skill": "optional"}
        Recv: {"type": "token", "text": "word"}
        Recv: {"type": "done", "full_response": "complete text", "latency_ms": 123}
        
        Send: {"type": "turn", "transcript": "...", "silence_ms": 500}
        Recv: {"type": "turn_result", "action": "RESPOND", "confidence": 0.9}
    """
    await websocket.accept()
    
    lpu = get_lpu()
    
    try:
        while True:
            data = await websocket.receive_json()
            msg_type = data.get("type", "think")
            
            if msg_type == "think":
                # Streaming inference
                start = time.time()
                text = data.get("text", "")
                skill = data.get("skill", "default")
                
                prompt = f"User: {text}\nAssistant:"
                skill_adapter = f"{skill}.lora" if skill != "default" else None
                
                if lpu is None:
                    await websocket.send_json({
                        "type": "error",
                        "message": "LPU not available"
                    })
                    continue
                
                full_response = ""
                try:
                    for chunk in lpu().chat.remote_gen(prompt, skill_adapter=skill_adapter):
                        await websocket.send_json({
                            "type": "token",
                            "text": chunk
                        })
                        full_response += chunk
                        
                except Exception as e:
                    await websocket.send_json({
                        "type": "error", 
                        "message": str(e)
                    })
                    continue
                
                latency = (time.time() - start) * 1000
                await websocket.send_json({
                    "type": "done",
                    "full_response": full_response.strip(),
                    "latency_ms": latency
                })
                
            elif msg_type == "turn":
                # Turn-taking analysis
                result = turn_detector.analyze(
                    transcript=data.get("transcript", ""),
                    silence_ms=data.get("silence_ms", 0),
                    is_agent_speaking=data.get("is_agent_speaking", False)
                )
                
                await websocket.send_json({
                    "type": "turn_result",
                    "action": result.action.value,
                    "confidence": result.confidence,
                    "reason": result.reason
                })
                
            elif msg_type == "ping":
                await websocket.send_json({"type": "pong"})
                
    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"WebSocket error: {e}")


# =============================================================================
# MODAL DEPLOYMENT
# =============================================================================

@app.function(
    image=brain_image,
    volumes={"/feedback": feedback_volume},
    keep_warm=1,  # Always ready (remove for cost savings)
    timeout=300,
)
@modal.asgi_app()
def fastapi_app():
    """Deploy FastAPI app to Modal."""
    return web_app


# =============================================================================
# LOCAL TESTING
# =============================================================================

@app.local_entrypoint()
def main():
    """Test the API locally."""
    import httpx
    
    print("Testing Fast Brain API...")
    
    # Get the deployed URL
    # In production, this would be your Modal URL
    base_url = "http://localhost:8000"
    
    # Test health
    print("\n1. Health Check:")
    # health = httpx.get(f"{base_url}/api/v1/health").json()
    # print(f"   Status: {health}")
    print("   (Run 'modal serve brain_api.py' to test locally)")
    
    # Test think
    print("\n2. Think Endpoint:")
    print("   POST /api/v1/think")
    print('   {"user_input": "What are your hours?", "skill": "plumber"}')
    
    # Test turn
    print("\n3. Turn Analysis:")
    print("   POST /api/v1/turn")
    print('   {"transcript": "Yeah so I was wondering...", "silence_ms": 300}')
    
    print("\n✅ Deploy with: modal deploy brain_api.py")
    print("   Your API will be at: https://<username>--fast-brain-api-fastapi-app.modal.run")
