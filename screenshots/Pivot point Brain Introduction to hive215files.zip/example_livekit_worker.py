"""
HIVE215 LiveKit Worker with Fast Brain Integration

This shows how to integrate the Brain client into your LiveKit worker.
The worker handles:
1. Audio from caller (LiveKit → Deepgram → text)
2. Brain thinking (text → Fast Brain API → response)
3. Audio to caller (response → Cartesia → LiveKit)

Integration Order:
1. First: Get LiveKit working with mock responses
2. Then: Swap in the Brain client (this file)
"""

import os
import asyncio
import logging
from typing import Optional

# LiveKit Agent SDK
from livekit import agents
from livekit.agents import (
    AutoSubscribe,
    JobContext,
    JobProcess,
    WorkerOptions,
    cli,
)
from livekit.agents.voice_assistant import VoiceAssistant
from livekit.plugins import deepgram, cartesia, silero

# Brain client
from brain_client import FastBrainClient, TurnAction

logger = logging.getLogger("hive215-worker")

# =============================================================================
# CONFIGURATION
# =============================================================================

# Fast Brain API URL (from environment)
FAST_BRAIN_URL = os.environ.get(
    "FAST_BRAIN_URL", 
    "https://your-username--fast-brain-api-fastapi-app.modal.run"
)

# Default skill for this worker (can be overridden per-call)
DEFAULT_SKILL = os.environ.get("DEFAULT_SKILL", "default")

# Voice provider keys
DEEPGRAM_API_KEY = os.environ.get("DEEPGRAM_API_KEY")
CARTESIA_API_KEY = os.environ.get("CARTESIA_API_KEY")


# =============================================================================
# BRAIN-POWERED LLM ADAPTER
# =============================================================================

class BrainLLM:
    """
    Adapter that makes Fast Brain look like a standard LLM to LiveKit.
    
    LiveKit's VoiceAssistant expects an LLM with certain methods.
    This wraps our Brain client to provide that interface.
    """
    
    def __init__(
        self, 
        brain_client: FastBrainClient,
        skill: str = "default",
    ):
        self.brain = brain_client
        self.skill = skill
        self._conversation_history = []
    
    async def chat(
        self,
        messages: list,
        **kwargs,
    ):
        """
        Generate a response given conversation history.
        This is called by VoiceAssistant when it's time to respond.
        """
        # Get the latest user message
        user_message = ""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                user_message = msg.get("content", "")
                break
        
        if not user_message:
            return
        
        # Stream response from Brain
        async for token in self.brain.stream(user_message, skill=self.skill):
            yield token
    
    def set_skill(self, skill: str):
        """Change the skill adapter mid-conversation."""
        self.skill = skill
        logger.info(f"Switched to skill: {skill}")


# =============================================================================
# BRAIN-POWERED TURN DETECTOR
# =============================================================================

class BrainTurnDetector:
    """
    Turn detector that uses Fast Brain for smarter endpoint detection.
    
    Instead of just silence-based detection, this uses semantic
    understanding of what the user said.
    """
    
    def __init__(self, brain_client: FastBrainClient):
        self.brain = brain_client
        self._transcript_buffer = ""
    
    async def should_interrupt(
        self,
        transcript: str,
        silence_ms: float,
        is_speaking: bool,
    ) -> bool:
        """
        Determine if the assistant should stop speaking.
        Called continuously during assistant speech.
        """
        if not transcript:
            return False
        
        result = await self.brain.analyze_turn(
            transcript=transcript,
            silence_ms=silence_ms,
            is_agent_speaking=is_speaking,
        )
        
        return result.action == TurnAction.INTERRUPT
    
    async def end_of_turn(
        self,
        transcript: str,
        silence_ms: float,
    ) -> bool:
        """
        Determine if the user has finished their turn.
        Called when user is speaking.
        """
        result = await self.brain.analyze_turn(
            transcript=transcript,
            silence_ms=silence_ms,
            is_agent_speaking=False,
        )
        
        return result.should_respond


# =============================================================================
# WORKER ENTRYPOINT
# =============================================================================

async def entrypoint(ctx: JobContext):
    """
    Main entrypoint for the LiveKit worker.
    Called when a new call/room is created.
    """
    logger.info(f"Worker starting for room: {ctx.room.name}")
    
    # Initialize Brain client
    brain = FastBrainClient(
        base_url=FAST_BRAIN_URL,
        default_skill=DEFAULT_SKILL,
    )
    
    # Check Brain health
    if not await brain.is_healthy():
        logger.warning("Brain service not healthy, will use fallback")
    
    # Determine skill from room metadata (if set)
    skill = DEFAULT_SKILL
    if ctx.room.metadata:
        import json
        try:
            metadata = json.loads(ctx.room.metadata)
            skill = metadata.get("skill", DEFAULT_SKILL)
        except:
            pass
    
    logger.info(f"Using skill: {skill}")
    
    # Create Brain-powered LLM
    llm = BrainLLM(brain, skill=skill)
    
    # Create turn detector
    turn_detector = BrainTurnDetector(brain)
    
    # Connect to the room
    await ctx.connect(auto_subscribe=AutoSubscribe.AUDIO_ONLY)
    
    # Wait for participant
    participant = await ctx.wait_for_participant()
    logger.info(f"Participant joined: {participant.identity}")
    
    # Build the voice assistant pipeline
    assistant = VoiceAssistant(
        vad=silero.VAD.load(),
        stt=deepgram.STT(api_key=DEEPGRAM_API_KEY),
        llm=llm,
        tts=cartesia.TTS(api_key=CARTESIA_API_KEY),
        # Optionally add turn detection:
        # turn_detector=turn_detector,
    )
    
    # Start the assistant
    assistant.start(ctx.room, participant)
    
    # Say initial greeting
    initial_greeting = await brain.think(
        "The user just connected. Give a brief greeting.",
        skill=skill,
    )
    await assistant.say(initial_greeting.text, allow_interruptions=True)
    
    # Keep running until room closes
    await asyncio.sleep(float("inf"))


# =============================================================================
# WORKER PROCESS SETUP
# =============================================================================

def prewarm(proc: JobProcess):
    """
    Called when the worker process starts.
    Use this to preload models/connections.
    """
    logger.info("Prewarming worker...")
    
    # Prewarm VAD model
    proc.userdata["vad"] = silero.VAD.load()
    
    # Prewarm Brain connection
    brain = FastBrainClient(
        base_url=FAST_BRAIN_URL,
        default_skill=DEFAULT_SKILL,
    )
    proc.userdata["brain"] = brain
    
    logger.info("Worker prewarmed and ready")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    # Validate configuration
    missing = []
    if not DEEPGRAM_API_KEY:
        missing.append("DEEPGRAM_API_KEY")
    if not CARTESIA_API_KEY:
        missing.append("CARTESIA_API_KEY")
    if not FAST_BRAIN_URL or "your-username" in FAST_BRAIN_URL:
        missing.append("FAST_BRAIN_URL")
    
    if missing:
        print("❌ Missing environment variables:")
        for var in missing:
            print(f"   - {var}")
        print("\nSet these before running the worker.")
        exit(1)
    
    # Run the worker
    cli.run_app(
        WorkerOptions(
            entrypoint_fnc=entrypoint,
            prewarm_fnc=prewarm,
        )
    )
