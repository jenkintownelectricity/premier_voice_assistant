# HIVE215 + Fast Brain Integration Guide

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    FAST BRAIN (Modal Cloud)                      │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────────────┐  │
│  │  BitNet LPU  │  │    Skills    │  │  Continuous Learner   │  │
│  │  (modal_lpu) │  │   (LoRAs)    │  │  (DPO Training)       │  │
│  └──────────────┘  └──────────────┘  └───────────────────────┘  │
│                          │                                       │
│                   ┌──────┴──────┐                               │
│                   │  brain_api  │  ← NEW (the missing piece)    │
│                   └──────┬──────┘                               │
└──────────────────────────┼──────────────────────────────────────┘
                           │
                    HTTP / WebSocket
                           │
┌──────────────────────────┼──────────────────────────────────────┐
│                      HIVE215 (Railway)                          │
│                          │                                       │
│  ┌──────────────┐  ┌─────┴──────┐  ┌───────────────────────┐   │
│  │   LiveKit    │  │   Brain    │  │      Main App         │   │
│  │   Worker     │──│   Client   │  │   (Dashboard, API)    │   │
│  │  (NEW)       │  │   (NEW)    │  │   (Existing)          │   │
│  └──────────────┘  └────────────┘  └───────────────────────┘   │
│         │                                                        │
│    ┌────┴────┐                                                  │
│    │ LiveKit │──► Audio In/Out                                  │
│    │  Cloud  │                                                  │
│    └─────────┘                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## What's Already Done

### Fast Brain (90% complete)
- ✅ `modal_lpu.py` - BitNet LPU inference engine
- ✅ `skill_factory.py` - Create LoRA adapters from business docs
- ✅ `continuous_learner.py` - DPO training from corrections
- ✅ `turn_taking.py` - Conversation flow logic
- ✅ `unified_dashboard.py` - Management UI
- ⏳ `brain_api.py` - **NEW** - HTTP/WebSocket API wrapper

### HIVE215 (needs LiveKit + Brain client)
- ✅ Main FastAPI app
- ✅ Dashboard
- ✅ Call logging
- ⏳ LiveKit Worker - **Cherry-pick from existing branch**
- ⏳ Brain Client - **NEW** - Connect to Fast Brain API

---

## Implementation Order

### DO THIS ORDER:

```
1. Deploy brain_api.py to Modal     (5 minutes)
2. Cherry-pick LiveKit code         (Claude Code)
3. Add brain_client.py to HIVE215   (5 minutes)
4. Configure environment variables  (2 minutes)
5. Deploy LiveKit worker to Railway (10 minutes)
6. Test end-to-end                  (5 minutes)
```

### Why This Order?

1. **Brain API first** - Independent of HIVE215, can test in isolation
2. **LiveKit second** - Gets audio working (can test with mock responses)
3. **Brain client last** - Just swaps mock → real brain

---

## Step 1: Deploy Fast Brain API

### 1.1 Add brain_api.py to your fast_brain repo

The file is already created at: `/home/claude/fast_brain-main/brain_api.py`

Copy it to your local fast_brain folder.

### 1.2 Deploy to Modal

```bash
cd fast_brain
modal deploy brain_api.py
```

### 1.3 Note your API URL

After deployment, Modal will show:
```
✓ Created web endpoint: https://your-username--fast-brain-api-fastapi-app.modal.run
```

Save this URL - you'll need it for HIVE215.

### 1.4 Test the API

```bash
# Health check
curl https://your-username--fast-brain-api-fastapi-app.modal.run/api/v1/health

# Test thinking
curl -X POST https://your-username--fast-brain-api-fastapi-app.modal.run/api/v1/think \
  -H "Content-Type: application/json" \
  -d '{"user_input": "What are your hours?", "skill": "default"}'
```

---

## Step 2: Add LiveKit to HIVE215

Tell Claude Code:

```
Cherry-pick commit 48a39a6 from branch claude/integrate-livekit-01PSewS9oi3BrQwezcMWAZ68
onto the current branch.

This brings in:
- backend/livekit_agent.py
- backend/livekit_api.py  
- backend/livekit_worker.py
- web/src/components/LiveKitVoiceCall.tsx
- web/src/components/VoiceCallWrapper.tsx
- Updated requirements.txt
- Updated package.json
```

---

## Step 3: Add Brain Client to HIVE215

### 3.1 Copy brain_client.py

Copy `/home/claude/hive215-brain-client/brain_client.py` to your HIVE215 `backend/` folder.

### 3.2 Update requirements.txt

Add to your existing requirements.txt:
```
httpx>=0.25.0
websockets>=12.0
```

### 3.3 Update the LiveKit worker

Modify `backend/livekit_worker.py` to use the Brain client.

The example at `/home/claude/hive215-brain-client/example_livekit_worker.py` shows how.

Key changes:
```python
# Add import
from brain_client import FastBrainClient

# Create client
brain = FastBrainClient(
    base_url=os.environ.get("FAST_BRAIN_URL"),
    default_skill=os.environ.get("DEFAULT_SKILL", "default"),
)

# Use for responses
response = await brain.think(user_text, skill="plumber")

# Or stream for lower latency
async for token in brain.stream(user_text):
    # Send to TTS as tokens arrive
    pass
```

---

## Step 4: Configure Environment Variables

### Railway Service #1 (Main App)

```env
# Existing vars (keep these)
DATABASE_URL=postgresql://...
LIVEKIT_URL=wss://your-project.livekit.cloud
LIVEKIT_API_KEY=APIxxxxxxxxx
LIVEKIT_API_SECRET=your-secret

# NEW: Fast Brain connection
FAST_BRAIN_URL=https://your-username--fast-brain-api-fastapi-app.modal.run
DEFAULT_SKILL=default
```

### Railway Service #2 (LiveKit Worker)

```env
# LiveKit credentials
LIVEKIT_URL=wss://your-project.livekit.cloud
LIVEKIT_API_KEY=APIxxxxxxxxx
LIVEKIT_API_SECRET=your-secret

# AI Pipeline
DEEPGRAM_API_KEY=your-deepgram-key
CARTESIA_API_KEY=your-cartesia-key

# Fast Brain
FAST_BRAIN_URL=https://your-username--fast-brain-api-fastapi-app.modal.run
DEFAULT_SKILL=default
```

---

## Step 5: Deploy LiveKit Worker to Railway

### 5.1 Create new Railway service

1. Go to your Railway project
2. Click **"+ New"** → **"Empty Service"**
3. Name it: `hive215-livekit-worker`

### 5.2 Connect to same repo

1. Settings → Source → Connect to your GitHub repo
2. Same branch as main app

### 5.3 Set start command

Settings → Deploy → Start Command:
```bash
cd backend && python livekit_worker.py dev
```

### 5.4 Add environment variables

Copy all the env vars from Step 4 (Worker section).

### 5.5 Deploy

Push to branch or click Deploy.

---

## Step 6: Test End-to-End

### 6.1 Check worker logs

In Railway, click on the worker service. You should see:
```
[INFO] Connecting to LiveKit Cloud...
[INFO] Agent registered successfully
[INFO] Waiting for participants...
```

### 6.2 Check LiveKit dashboard

Go to https://cloud.livekit.io → Your project → Agents tab.
Your worker should be listed.

### 6.3 Make a test call

Use your HIVE215 dashboard to initiate a call.

Watch the logs:
1. Worker receives audio
2. Deepgram transcribes
3. Brain client calls Fast Brain API
4. Response comes back
5. Cartesia speaks it
6. Caller hears the response

---

## Troubleshooting

### Brain API returns 503
- Check that `modal_lpu.py` is deployed: `modal deploy modal_lpu.py`
- Check Modal dashboard for errors

### LiveKit worker won't connect
- Verify LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET are correct
- Check that LiveKit Cloud project exists

### No audio in calls
- Verify Deepgram and Cartesia keys are valid
- Check worker logs for API errors

### High latency
- Enable `keep_warm=1` in brain_api.py for always-on LPU
- Use streaming (`brain.stream()`) instead of `brain.think()`

---

## Files Reference

### Fast Brain (add to your repo)
```
fast_brain/
├── modal_lpu.py           # Existing - LPU inference
├── brain_api.py           # NEW - API wrapper
├── skill_factory.py       # Existing - Create skills
├── continuous_learner.py  # Existing - Learning loop
├── turn_taking.py         # Existing - Conversation flow
└── unified_dashboard.py   # Existing - Management UI
```

### HIVE215 (add to your repo)
```
hive215/
├── backend/
│   ├── main.py            # Existing
│   ├── brain_client.py    # NEW - Connect to Fast Brain
│   ├── livekit_worker.py  # Cherry-picked + modified
│   └── ...
└── web/
    └── ...
```

---

## Next Steps After Integration

1. **Create your first skill**
   ```bash
   cd fast_brain
   python skill_factory.py
   # Upload docs, create "plumber.lora"
   ```

2. **Deploy the skill**
   ```bash
   modal volume put lpu-skills adapters/plumber /root/skills/plumber.lora
   ```

3. **Use the skill**
   - Set `DEFAULT_SKILL=plumber` in Railway
   - Or pass skill per-call via room metadata

4. **Monitor and improve**
   - Check feedback logs in Modal volume
   - Run `continuous_learner.py` weekly to improve skills

---

## Architecture Benefits Recap

| Benefit | How It Works |
|---------|--------------|
| **Platform agnostic** | Brain API works with any voice platform |
| **Train once, sell everywhere** | Same skill works on HIVE215, Vapi, Retell |
| **Continuous improvement** | Agents get smarter from corrections |
| **Cost efficient** | BitNet runs on CPU, no GPU needed |
| **Separation of concerns** | Voice team ≠ AI team |

Your brain. Any voice. Maximum leverage. 🧠🐝
